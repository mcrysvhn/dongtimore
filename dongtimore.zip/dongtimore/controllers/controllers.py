# -*- coding: utf-8 -*-
from odoo import http

# class Dongtimore(http.Controller):
#     @http.route('/dongtimore/dongtimore/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/dongtimore/dongtimore/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('dongtimore.listing', {
#             'root': '/dongtimore/dongtimore',
#             'objects': http.request.env['dongtimore.dongtimore'].search([]),
#         })

#     @http.route('/dongtimore/dongtimore/objects/<model("dongtimore.dongtimore"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('dongtimore.object', {
#             'object': obj
#         })