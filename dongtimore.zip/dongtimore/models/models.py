# -*- coding: utf-8 -*-

from odoo import models, fields, api

class dongtimore(models.Model):
    _name = 'dongtimore.dongtimore'

    name = fields.Char()
    age = fields.Char()
    gender = fields.Many2one()
    value = fields.Integer()
    value2 = fields.Float(compute="_value_pc", store=True)
    answer = fields.Integer()
    answer2 = fields.Float()
    answer3 = fields.Integer()
    answer4 = fields.Float()
    answer5 = fields.Integer()
    answer6 = fields.Float()
    description = fields.Text()

    @api.depends('value')
    def _value_pc(self):
        self.value2 = float(self.value) / 100

    state = fields.Selection([
            ('draft', 'Quotation'),
            ('sent', 'Quotation Sent'),
            ('sale', 'Sales Order'),
            ('done', 'Done'),
            ('cancel', 'Cancelled'),
        ], string='Order Status', readonly=True, copy=False, store=True, default='draft')
